// EMPIRE STORE starter shop. Change the WhatsApp number below before publishing.
const WHATSAPP_NUMBER = "2348000000000"; // Replace with your number: country code + number, digits only.
const money = amount => new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(amount);

const products = [
  {id:1,name:"The Signature Blazer",category:"Clothing",price:45000,tag:"BESTSELLER",image:"https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+blazer"},
  {id:2,name:"Everyday Luxe Set",category:"Clothing",price:38000,tag:"NEW IN",image:"https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+two+piece+outfit"},
  {id:3,name:"Empire Street Sneakers",category:"Shoes",price:52000,tag:"SIGNATURE",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+sneakers"},
  {id:4,name:"Classic Timepiece",category:"Accessories",price:9999,tag:"JUMIA PICK",image:"https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/mlp-mens-gift-set/"},
  {id:5,name:"Modern Monochrome",category:"Clothing",price:42000,tag:"EDITOR'S PICK",image:"https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=mens+fashion"},
  {id:6,name:"City Leather Shoes",category:"Shoes",price:48000,tag:"ESSENTIAL",image:"https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+formal+shoes"},
  {id:7,name:"Leather Bracelet Set",category:"Accessories",price:3629,tag:"JUMIA PICK",image:"https://images.unsplash.com/photo-1611591437281-460bfbe1220a?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/mlp-accessory-sets-for-men/"},
  {id:8,name:"Men's Cuban Chain & Bracelet",category:"Accessories",price:4320,tag:"JUMIA PICK",image:"https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/slp/boxed-men-bracelets-set"},
  {id:9,name:"4-in-1 Watch & Jewelry Set",category:"Accessories",price:9999,tag:"GIFT PICK",image:"https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/slp/male-jewelry-set-with-watches"},
  {id:10,name:"7-in-1 Men's Gift Box",category:"Accessories",price:29999,tag:"GIFT PICK",image:"https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/mlp-gifts-for-men/"},
  {id:11,name:"Everyday Crossbody",category:"Accessories",price:27000,tag:"JUST IN",image:"https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+crossbody+bag"},
  {id:12,name:"The Weekend Fit",category:"Clothing",price:35000,tag:"LIMITED EDIT",image:"https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=700&q=80",source:"https://www.jumia.com.ng/catalog/?q=men+casual+wear"}
];
let cart = [];
let activeFilter = "All";
const grid = document.getElementById("productGrid");
const cartDrawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const toast = document.getElementById("toast");

function renderProducts(){
  const shown = activeFilter === "All" ? products : products.filter(p=>p.category===activeFilter);
  grid.innerHTML = shown.map(p=>`<article class="product-card">
    <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="product-tag">${p.tag}</span><button class="add-button" data-add="${p.id}">ADD TO BAG +</button></div>
    <div class="product-meta"><span class="product-name">${p.name}</span><span class="price">${money(p.price)}</span></div>
    <div class="product-category">${p.category}</div><a class="source-link" href="${p.source}" target="_blank" rel="noopener">CHECK ON JUMIA ↗</a>
  </article>`).join("");
}
function showToast(message){toast.textContent=message;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),2200)}
function updateCart(){
  const count = cart.reduce((sum,item)=>sum+item.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("drawerCount").textContent=`(${count})`;
  document.getElementById("subtotal").textContent=money(cart.reduce((sum,item)=>sum+item.price*item.qty,0));
  const items=document.getElementById("cartItems");
  if(!cart.length){items.innerHTML='<p class="empty-cart">Your bag is waiting for something special.</p>';return}
  items.innerHTML=cart.map(item=>`<div class="cart-item"><img src="${item.image}" alt=""><div><strong>${item.name}</strong><small>${money(item.price)}</small><div class="qty"><button data-qty="${item.id}" data-change="-1" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-qty="${item.id}" data-change="1" aria-label="Increase quantity">+</button></div></div><button class="remove" data-remove="${item.id}" aria-label="Remove item">✕</button></div>`).join("");
}
function openCart(){cartDrawer.classList.add("open");overlay.classList.add("open");cartDrawer.setAttribute("aria-hidden","false")}
function closeCart(){cartDrawer.classList.remove("open");overlay.classList.remove("open");cartDrawer.setAttribute("aria-hidden","true")}
grid.addEventListener("click",e=>{const btn=e.target.closest("[data-add]");if(!btn)return;const p=products.find(x=>x.id===Number(btn.dataset.add));const found=cart.find(x=>x.id===p.id);if(found)found.qty++;else cart.push({...p,qty:1});updateCart();showToast(`${p.name} added to your bag`)});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");activeFilter=btn.dataset.filter;renderProducts()}));
document.getElementById("cartButton").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.getElementById("cartItems").addEventListener("click",e=>{
  const q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");
  if(q){const item=cart.find(x=>x.id===Number(q.dataset.qty));item.qty+=Number(q.dataset.change);if(item.qty<=0)cart=cart.filter(x=>x.id!==item.id)}
  if(r)cart=cart.filter(x=>x.id!==Number(r.dataset.remove));
  updateCart();
});
document.getElementById("checkout").addEventListener("click",()=>{
  if(!cart.length){showToast("Add a product to your bag first.");return}
  if(WHATSAPP_NUMBER==="2348000000000"){showToast("Set your real WhatsApp number in app.js first.");return}
  const lines=cart.map(i=>`• ${i.name} x${i.qty} — ${money(i.price*i.qty)}`).join("\n");
  const total=money(cart.reduce((sum,i)=>sum+i.price*i.qty,0));
  const msg=`Hello EMPIRE STORE! I'd like to place this order:\n\n${lines}\n\nSubtotal: ${total}\n\nPlease confirm availability, current price, delivery fee and payment details before I pay.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,"_blank","noopener");
});
document.getElementById("newsletterForm").addEventListener("submit",e=>{e.preventDefault();document.getElementById("newsletterMessage").textContent="Thanks for your interest! Email signup needs to be connected before launch.";document.getElementById("newsletterEmail").value=""});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("nav").classList.toggle("show"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("show")));
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("whatsappLink").addEventListener("click",e=>{e.preventDefault();if(WHATSAPP_NUMBER==="2348000000000"){showToast("Add your WhatsApp number in app.js first.");return}window.open(`https://wa.me/${WHATSAPP_NUMBER}`,"_blank","noopener")});
renderProducts();updateCart();